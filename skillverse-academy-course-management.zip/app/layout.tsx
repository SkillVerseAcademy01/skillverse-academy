import "./globals.css";

export const metadata = {
  title: "SkillVerse Academy",
  description: "Course Management Platform"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}